
import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
/**
 * Servlet implementation class form
 */
@WebServlet("/form")
public class form extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public form() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		String fname = request.getParameter("name");
		String email= request.getParameter("email");
		String sub= request.getParameter("subject");
		String mes= request.getParameter("message");
		mes = mes.replace("'", "\''");
		PrintWriter out = response.getWriter();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sportsschool","root","");
			Statement insert = con.createStatement();
			insert.executeUpdate("INSERT INTO messages (mid, fullname, email, subject, message) VALUES (null, '"+fname+"', '"+email+"', '"+sub+"', '"+mes+"')");
		} catch (Exception e) {
			out.print(e);
		}
		
		out.println("<h1 style='margin-top: 5em; Background-color: #415380; color: #aee5d1; text-align: center; font-family: \"Brush Script MT\"; font-size: 3em;'>");
		out.println("thank you for your message- " + "<br>" + fname + "!" + "<br> Someone will contact you very soon." );
		out.println("</h1>");
	}
}
